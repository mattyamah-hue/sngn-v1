# sNGN V1.3

V1.3 adds the operational layer required to move the sandbox engine toward controlled external testing.

## Added

- Provider event persistence and idempotent webhook event records.
- KYC provider interface + sandbox adapter.
- Risk provider interface + sandbox adapter.
- KYC and provider-risk audit records.
- Automated reconciliation worker with persisted job status.
- Sandbox evidence capture endpoint.
- Additional indexes and operational database records.

## API

- `POST /v1/kyc/check` — authenticated sandbox KYC check.
- `POST /v1/admin/risk/screen` — admin sandbox risk-provider test.
- `POST /v1/admin/reconciliation/run` — execute a reconciliation job.
- `POST /v1/admin/sandbox/evidence` — capture evidence from the current database state.

## Worker

Set:

```env
ENABLE_RECONCILIATION_WORKER=true
SANDBOX_EXTERNAL_POSITION_MINOR=0
SANDBOX_PROVIDER_NAME=SANDBOX
RECONCILIATION_INTERVAL_MS=300000
```

The worker is intentionally disabled by default.

## Verification

Run against PostgreSQL:

```bash
npm install
npm run db:migrate
npm run typecheck
npm run build
npm test
```

A live provider is not embedded or simulated as a licensed banking rail. The provider interfaces are the integration boundary for an authorized PSP/bank/financial partner.

## Sandbox evidence

Evidence should be generated only from actual test executions. It records transaction, ledger, webhook and reconciliation evidence without claiming that a sandbox result is live-money authorization.
