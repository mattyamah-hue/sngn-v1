-- sNGN V1.4 hardening: provider state transitions, security controls,
-- KYC/risk enforcement metadata, reconciliation exceptions, test evidence.

CREATE TYPE reconciliation_exception_status AS ENUM ('OPEN','INVESTIGATING','RESOLVED','WAIVED');
CREATE TYPE security_event_severity AS ENUM ('INFO','LOW','MEDIUM','HIGH','CRITICAL');

ALTER TABLE users ADD COLUMN IF NOT EXISTS risk_tier TEXT NOT NULL DEFAULT 'STANDARD';
ALTER TABLE users ADD COLUMN IF NOT EXISTS kyc_verified_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN IF NOT EXISTS restricted_reason TEXT;

ALTER TABLE funding_requests ADD COLUMN IF NOT EXISTS provider_status TEXT;
ALTER TABLE funding_requests ADD COLUMN IF NOT EXISTS failure_code TEXT;
ALTER TABLE funding_requests ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE redemption_requests ADD COLUMN IF NOT EXISTS provider_status TEXT;
ALTER TABLE redemption_requests ADD COLUMN IF NOT EXISTS failure_code TEXT;
ALTER TABLE redemption_requests ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT now();

ALTER TABLE provider_events ADD COLUMN IF NOT EXISTS signature_verified_at TIMESTAMPTZ;
ALTER TABLE provider_events ADD COLUMN IF NOT EXISTS processing_attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE provider_events ADD COLUMN IF NOT EXISTS last_error TEXT;

CREATE TABLE IF NOT EXISTS reconciliation_exceptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id UUID NOT NULL REFERENCES reconciliation_runs(id),
  status reconciliation_exception_status NOT NULL DEFAULT 'OPEN',
  difference_minor BIGINT NOT NULL,
  reason TEXT NOT NULL,
  owner TEXT,
  resolution TEXT,
  resolved_by UUID REFERENCES users(id),
  opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS reconciliation_exceptions_status_idx ON reconciliation_exceptions(status, opened_at DESC);

CREATE TABLE IF NOT EXISTS security_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID REFERENCES users(id),
  event_type TEXT NOT NULL,
  severity security_event_severity NOT NULL DEFAULT 'INFO',
  request_id TEXT,
  ip_hash TEXT,
  user_agent_hash TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS security_events_created_idx ON security_events(created_at DESC);

CREATE TABLE IF NOT EXISTS api_request_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id TEXT NOT NULL,
  actor_id UUID REFERENCES users(id),
  method TEXT NOT NULL,
  route TEXT NOT NULL,
  status_code INTEGER NOT NULL,
  duration_ms INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS api_request_events_created_idx ON api_request_events(created_at DESC);

CREATE TABLE IF NOT EXISTS sandbox_test_cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  expected_result TEXT NOT NULL,
  actual_result TEXT,
  status TEXT NOT NULL CHECK (status IN ('PASS','FAIL','NOT_RUN')) DEFAULT 'NOT_RUN',
  evidence JSONB NOT NULL DEFAULT '{}',
  executed_at TIMESTAMPTZ
);

-- Provider event processing must be idempotent at the database boundary.
CREATE UNIQUE INDEX IF NOT EXISTS provider_events_unique_event_idx
  ON provider_events(provider_name, external_event_id);
