-- sNGN V1.3: provider settlement events, KYC/risk adapter records,
-- reconciliation job state, sandbox evidence and operational hardening.

CREATE TYPE provider_event_status AS ENUM ('RECEIVED','APPLIED','IGNORED','FAILED');
CREATE TYPE kyc_status AS ENUM ('UNVERIFIED','PENDING','VERIFIED','RESTRICTED','REJECTED');
CREATE TYPE reconciliation_job_status AS ENUM ('RUNNING','COMPLETED','FAILED');

ALTER TABLE users ADD COLUMN IF NOT EXISTS kyc_status kyc_status NOT NULL DEFAULT 'UNVERIFIED';
ALTER TABLE users ADD COLUMN IF NOT EXISTS kyc_provider TEXT;
ALTER TABLE users ADD COLUMN IF NOT EXISTS kyc_reference TEXT;

CREATE TABLE IF NOT EXISTS provider_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name TEXT NOT NULL,
  external_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  external_reference TEXT,
  amount_minor BIGINT,
  currency TEXT,
  status provider_event_status NOT NULL DEFAULT 'RECEIVED',
  payload JSONB NOT NULL DEFAULT '{}',
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ,
  error TEXT,
  UNIQUE(provider_name, external_event_id)
);
CREATE INDEX IF NOT EXISTS provider_events_reference_idx ON provider_events(provider_name, external_reference);

CREATE TABLE IF NOT EXISTS kyc_checks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  provider_name TEXT NOT NULL,
  provider_reference TEXT,
  status kyc_status NOT NULL,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  raw JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS kyc_checks_user_idx ON kyc_checks(user_id, requested_at DESC);

CREATE TABLE IF NOT EXISTS risk_checks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  transaction_id UUID REFERENCES transactions(id),
  provider_name TEXT NOT NULL,
  decision risk_decision NOT NULL,
  provider_reference TEXT,
  reason TEXT,
  raw JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS risk_checks_tx_idx ON risk_checks(transaction_id, created_at DESC);

CREATE TABLE IF NOT EXISTS reconciliation_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name TEXT NOT NULL,
  status reconciliation_job_status NOT NULL DEFAULT 'RUNNING',
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  run_id UUID REFERENCES reconciliation_runs(id),
  error TEXT
);
CREATE INDEX IF NOT EXISTS reconciliation_jobs_created_idx ON reconciliation_jobs(started_at DESC);

CREATE TABLE IF NOT EXISTS sandbox_evidence_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scenario TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PASS','FAIL','INCOMPLETE')),
  summary JSONB NOT NULL DEFAULT '{}',
  artifact JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_events_created_idx ON audit_events(created_at DESC);
