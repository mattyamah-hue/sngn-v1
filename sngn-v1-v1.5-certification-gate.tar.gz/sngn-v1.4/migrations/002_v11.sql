-- sNGN V1.1: provisioning, authentication, funding/issuance, redemption, reconciliation.

CREATE TYPE funding_status AS ENUM ('CREATED','PENDING','CONFIRMED','FAILED');
CREATE TYPE redemption_status AS ENUM ('CREATED','PENDING','CONFIRMED','FAILED','REVERSED');
CREATE TYPE user_kind AS ENUM ('CUSTOMER','MERCHANT','ADMIN');

ALTER TABLE users ADD COLUMN IF NOT EXISTS kind user_kind NOT NULL DEFAULT 'CUSTOMER';
ALTER TABLE users ADD COLUMN IF NOT EXISTS api_key_hash TEXT UNIQUE;

CREATE TABLE IF NOT EXISTS api_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  key_prefix TEXT NOT NULL,
  key_hash TEXT UNIQUE NOT NULL,
  status account_status NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_used_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS api_credentials_user_idx ON api_credentials(user_id);

CREATE TABLE IF NOT EXISTS funding_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  wallet_id UUID NOT NULL REFERENCES wallets(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL DEFAULT 'SNGN',
  status funding_status NOT NULL DEFAULT 'CREATED',
  provider_reference TEXT,
  transaction_id UUID REFERENCES transactions(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS funding_user_idx ON funding_requests(user_id, created_at);

CREATE TABLE IF NOT EXISTS redemption_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  wallet_id UUID NOT NULL REFERENCES wallets(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL DEFAULT 'SNGN',
  bank_code TEXT NOT NULL,
  account_number TEXT NOT NULL,
  status redemption_status NOT NULL DEFAULT 'CREATED',
  provider_reference TEXT,
  transaction_id UUID REFERENCES transactions(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS redemption_user_idx ON redemption_requests(user_id, created_at);

CREATE TABLE IF NOT EXISTS reconciliation_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name TEXT NOT NULL,
  as_of TIMESTAMPTZ NOT NULL DEFAULT now(),
  internal_amount_minor BIGINT NOT NULL,
  external_amount_minor BIGINT NOT NULL,
  difference_minor BIGINT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('RECONCILED','EXCEPTION')),
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reconciliation_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id UUID NOT NULL REFERENCES reconciliation_runs(id),
  external_reference TEXT,
  internal_reference TEXT,
  amount_minor BIGINT NOT NULL,
  status TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Controlled system accounts. They are created once and used as the ledger counterparty
-- for sandbox issuance/redemption. They do not represent a claim that live reserves exist.
INSERT INTO ledger_accounts (code, kind, currency)
VALUES
  ('SNGN_BACKING_ASSET', 'SYSTEM', 'SNGN'),
  ('SNGN_REDEMPTION_ASSET', 'SYSTEM', 'SNGN')
ON CONFLICT (code) DO NOTHING;

CREATE INDEX IF NOT EXISTS ledger_entries_tx_idx ON ledger_entries(transaction_id);
CREATE INDEX IF NOT EXISTS transactions_external_ref_idx ON transactions(external_reference);

CREATE OR REPLACE FUNCTION assert_balanced_settled_transaction() RETURNS trigger AS $$
DECLARE
  debits BIGINT;
  credits BIGINT;
BEGIN
  IF NEW.status = 'SETTLED' THEN
    SELECT COALESCE(SUM(amount_minor) FILTER (WHERE entry_type='DEBIT'),0),
           COALESCE(SUM(amount_minor) FILTER (WHERE entry_type='CREDIT'),0)
      INTO debits, credits
      FROM ledger_entries WHERE transaction_id = NEW.id;
    IF debits <> credits OR debits <> NEW.amount_minor THEN
      RAISE EXCEPTION 'settled transaction is not balanced';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS transactions_balanced_on_settlement ON transactions;
CREATE CONSTRAINT TRIGGER transactions_balanced_on_settlement
AFTER INSERT OR UPDATE ON transactions
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION assert_balanced_settled_transaction();
