-- sNGN V1.2: risk, limits, disputes/refunds, signed webhooks, observability.

CREATE TYPE risk_decision AS ENUM ('ALLOW','BLOCK','REVIEW');
CREATE TYPE dispute_status AS ENUM ('OPEN','UNDER_REVIEW','RESOLVED','REJECTED');

CREATE TABLE IF NOT EXISTS account_limits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id),
  single_tx_limit_minor BIGINT NOT NULL DEFAULT 50000000,
  daily_limit_minor BIGINT NOT NULL DEFAULT 200000000,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(owner_id)
);

CREATE TABLE IF NOT EXISTS risk_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id),
  decision risk_decision NOT NULL DEFAULT 'ALLOW',
  risk_tier TEXT NOT NULL DEFAULT 'STANDARD',
  reason TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES transactions(id),
  user_id UUID NOT NULL REFERENCES users(id),
  status dispute_status NOT NULL DEFAULT 'OPEN',
  reason TEXT NOT NULL,
  evidence JSONB NOT NULL DEFAULT '{}',
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS disputes_tx_idx ON disputes(transaction_id);

CREATE TABLE IF NOT EXISTS webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name TEXT NOT NULL,
  event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  signature_valid BOOLEAN NOT NULL,
  payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider_name, event_id)
);

CREATE TABLE IF NOT EXISTS observability_events (
  id BIGSERIAL PRIMARY KEY,
  event_name TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('INFO','WARN','ERROR','CRITICAL')),
  duration_ms INTEGER,
  correlation_id TEXT,
  data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS observability_created_idx ON observability_events(created_at);

CREATE TABLE IF NOT EXISTS provider_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_name TEXT NOT NULL,
  external_reference TEXT NOT NULL,
  event_type TEXT NOT NULL,
  amount_minor BIGINT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'SNGN',
  status TEXT NOT NULL,
  raw JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(provider_name, external_reference, event_type)
);

CREATE INDEX IF NOT EXISTS transactions_sender_created_idx ON transactions(sender_ledger_account_id, created_at);
CREATE INDEX IF NOT EXISTS transactions_status_idx ON transactions(status);

-- Default sandbox limits for existing users.
INSERT INTO account_limits(owner_id)
SELECT id FROM users ON CONFLICT (owner_id) DO NOTHING;
INSERT INTO risk_profiles(user_id)
SELECT id FROM users ON CONFLICT (user_id) DO NOTHING;
