CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE account_status AS ENUM ('ACTIVE','FROZEN','CLOSED');
CREATE TYPE account_kind AS ENUM ('CUSTOMER','MERCHANT','SYSTEM');
CREATE TYPE tx_status AS ENUM ('CREATED','AUTHENTICATING','VALIDATING','RISK_CHECK','AUTHORIZED','POSTING','SETTLED','FAILED','BLOCKED','REQUIRES_REVIEW','REVERSED','REFUNDED');
CREATE TYPE entry_type AS ENUM ('DEBIT','CREDIT');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  status account_status NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES users(id),
  currency TEXT NOT NULL DEFAULT 'SNGN',
  status account_status NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(owner_id, currency)
);

CREATE TABLE ledger_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID REFERENCES wallets(id),
  code TEXT UNIQUE NOT NULL,
  kind account_kind NOT NULL,
  currency TEXT NOT NULL DEFAULT 'SNGN',
  status account_status NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL,
  status tx_status NOT NULL DEFAULT 'CREATED',
  currency TEXT NOT NULL DEFAULT 'SNGN',
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  sender_ledger_account_id UUID REFERENCES ledger_accounts(id),
  recipient_ledger_account_id UUID REFERENCES ledger_accounts(id),
  external_reference TEXT,
  failure_code TEXT,
  metadata JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  settled_at TIMESTAMPTZ
);

CREATE TABLE ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES transactions(id),
  ledger_account_id UUID NOT NULL REFERENCES ledger_accounts(id),
  entry_type entry_type NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID REFERENCES transactions(id),
  actor_id UUID REFERENCES users(id),
  event_type TEXT NOT NULL,
  data JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE idempotency_keys (
  key TEXT PRIMARY KEY,
  request_hash TEXT NOT NULL,
  transaction_id UUID REFERENCES transactions(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX ledger_entries_account_idx ON ledger_entries(ledger_account_id);
CREATE INDEX transactions_created_idx ON transactions(created_at);
CREATE INDEX audit_events_tx_idx ON audit_events(transaction_id);

CREATE OR REPLACE FUNCTION prevent_settled_transaction_update() RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'SETTLED' AND NEW.status <> 'REFUNDED' AND NEW.status <> 'REVERSED' THEN
    RAISE EXCEPTION 'settled transaction is immutable';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER transactions_immutable_after_settlement
BEFORE UPDATE ON transactions
FOR EACH ROW EXECUTE FUNCTION prevent_settled_transaction_update();
