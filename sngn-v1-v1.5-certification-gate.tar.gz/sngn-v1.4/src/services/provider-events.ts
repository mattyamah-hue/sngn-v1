import { pool, withTx } from '../db.js';
import { randomUUID } from 'node:crypto';

export type ProviderEvent = {
  providerName: string;
  externalEventId: string;
  eventType: string;
  externalReference?: string;
  amountMinor?: bigint;
  currency?: string;
  payload: Record<string, unknown>;
};

export async function applyProviderEvent(event: ProviderEvent) {
  return withTx(async client => {
    const inserted = await client.query<{id:string}>(
      `INSERT INTO provider_events(provider_name,external_event_id,event_type,external_reference,amount_minor,currency,payload,status,processing_attempts)
       VALUES($1,$2,$3,$4,$5,$6,$7,'RECEIVED',1)
       ON CONFLICT(provider_name,external_event_id) DO NOTHING RETURNING id`,
      [event.providerName,event.externalEventId,event.eventType,event.externalReference ?? null,event.amountMinor?.toString() ?? null,event.currency ?? null,JSON.stringify(event.payload)]
    );
    if (!inserted.rowCount) return { duplicate: true, status: 'IGNORED' };

    try {
      if (!event.externalReference) throw new Error('PROVIDER_REFERENCE_REQUIRED');

      if (event.eventType.startsWith('FUNDING.')) {
        const funding = await client.query<{id:string; transaction_id:string|null}>(
          `SELECT id,transaction_id FROM funding_requests WHERE provider_reference=$1 FOR UPDATE`, [event.externalReference]
        );
        if (!funding.rowCount) throw new Error('FUNDING_NOT_FOUND');
        const status = event.eventType === 'FUNDING.CONFIRMED' ? 'CONFIRMED' : event.eventType === 'FUNDING.FAILED' ? 'FAILED' : 'PENDING';
        await client.query(`UPDATE funding_requests SET status=$1,provider_status=$2,updated_at=now(),confirmed_at=CASE WHEN $1='CONFIRMED' THEN now() ELSE confirmed_at END WHERE id=$3`, [status,event.eventType,funding.rows[0].id]);
      } else if (event.eventType.startsWith('PAYOUT.')) {
        const redemption = await client.query<{id:string; transaction_id:string|null}>(
          `SELECT id,transaction_id FROM redemption_requests WHERE provider_reference=$1 FOR UPDATE`, [event.externalReference]
        );
        if (!redemption.rowCount) throw new Error('REDEMPTION_NOT_FOUND');
        const status = event.eventType === 'PAYOUT.CONFIRMED' ? 'CONFIRMED' : event.eventType === 'PAYOUT.FAILED' ? 'FAILED' : 'PENDING';
        await client.query(`UPDATE redemption_requests SET status=$1,provider_status=$2,updated_at=now(),confirmed_at=CASE WHEN $1='CONFIRMED' THEN now() ELSE confirmed_at END WHERE id=$3`, [status,event.eventType,redemption.rows[0].id]);
      }

      await client.query(`UPDATE provider_events SET status='APPLIED',processed_at=now() WHERE id=$1`, [inserted.rows[0].id]);
      return { duplicate:false, status:'APPLIED', providerEventId: inserted.rows[0].id };
    } catch (e) {
      const message = e instanceof Error ? e.message : 'PROVIDER_EVENT_FAILED';
      await client.query(`UPDATE provider_events SET status='FAILED',last_error=$2,processed_at=now() WHERE id=$1`, [inserted.rows[0].id,message]);
      throw e;
    }
  });
}

export async function listProviderEventFailures() {
  const r = await pool.query(`SELECT * FROM provider_events WHERE status='FAILED' ORDER BY received_at DESC LIMIT 100`);
  return r.rows;
}
