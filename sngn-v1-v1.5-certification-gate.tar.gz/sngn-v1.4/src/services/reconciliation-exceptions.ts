import { pool } from '../db.js';

export async function openReconciliationException(runId:string,differenceMinor:bigint,reason:string) {
  const r = await pool.query(`INSERT INTO reconciliation_exceptions(run_id,difference_minor,reason) VALUES($1,$2,$3) RETURNING *`,[runId,differenceMinor.toString(),reason]);
  return r.rows[0];
}

export async function resolveReconciliationException(id:string,status:'RESOLVED'|'WAIVED',resolution:string,resolvedBy:string) {
  const r = await pool.query(`UPDATE reconciliation_exceptions SET status=$2,resolution=$3,resolved_by=$4,resolved_at=now() WHERE id=$1 AND status IN ('OPEN','INVESTIGATING') RETURNING *`,[id,status,resolution,resolvedBy]);
  if (!r.rowCount) throw new Error('RECONCILIATION_EXCEPTION_NOT_FOUND');
  return r.rows[0];
}
