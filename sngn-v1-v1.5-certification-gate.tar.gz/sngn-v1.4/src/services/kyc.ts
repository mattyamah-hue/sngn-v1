import { pool } from '../db.js';
import type { KycProvider } from '../providers/kyc-provider.js';

export async function runKycCheck(provider: KycProvider, userId: string) {
  const user = await pool.query<{display_name:string;email:string}>(`SELECT display_name,email FROM users WHERE id=$1`, [userId]);
  if (!user.rowCount) throw new Error('USER_NOT_FOUND');
  const result = await provider.verifyIdentity({ userId, fullName: user.rows[0].display_name, email: user.rows[0].email });
  await pool.query(`INSERT INTO kyc_checks(user_id,provider_name,provider_reference,status,completed_at,raw) VALUES($1,$2,$3,$4,now(),$5)`, [userId, provider.constructor.name, result.providerReference, result.decision, JSON.stringify(result.raw ?? {})]);
  await pool.query(`UPDATE users SET kyc_status=$2, kyc_provider=$3, kyc_reference=$4, kyc_verified_at=CASE WHEN $2='VERIFIED' THEN now() ELSE kyc_verified_at END WHERE id=$1`, [userId, result.decision, provider.constructor.name, result.providerReference]);
  return result;
}
