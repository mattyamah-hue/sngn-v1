import { randomUUID } from 'node:crypto';
import { withTx } from '../db.js';

export async function openDispute(input: { userId: string; transactionId: string; reason: string; evidence?: Record<string, unknown> }) {
  return withTx(async client => {
    const tx = await client.query(`SELECT id,status FROM transactions WHERE id=$1`, [input.transactionId]);
    if (!tx.rowCount) throw new Error('TRANSACTION_NOT_FOUND');
    const existing = await client.query(`SELECT id,status FROM disputes WHERE transaction_id=$1 AND user_id=$2 AND status IN ('OPEN','UNDER_REVIEW')`, [input.transactionId, input.userId]);
    if (existing.rowCount) return existing.rows[0];
    const id = randomUUID();
    await client.query(`INSERT INTO disputes(id,transaction_id,user_id,reason,evidence) VALUES($1,$2,$3,$4,$5)`, [id,input.transactionId,input.userId,input.reason,JSON.stringify(input.evidence ?? {})]);
    await client.query(`INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'DISPUTE_OPENED',$3)`, [input.transactionId,input.userId,JSON.stringify({disputeId:id})]);
    return { id, status:'OPEN' };
  });
}

export async function resolveDispute(input: { disputeId: string; actorId: string; resolution: string; status: 'RESOLVED'|'REJECTED' }) {
  return withTx(async client => {
    const r = await client.query<{ transaction_id:string }>(`UPDATE disputes SET status=$2,resolution=$3,resolved_at=now() WHERE id=$1 AND status IN ('OPEN','UNDER_REVIEW') RETURNING transaction_id`, [input.disputeId,input.status,input.resolution]);
    if (!r.rowCount) throw new Error('DISPUTE_NOT_OPEN');
    await client.query(`INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'DISPUTE_RESOLVED',$3)`, [r.rows[0].transaction_id,input.actorId,JSON.stringify({disputeId:input.disputeId,status:input.status})]);
    return { disputeId: input.disputeId, status: input.status };
  });
}
