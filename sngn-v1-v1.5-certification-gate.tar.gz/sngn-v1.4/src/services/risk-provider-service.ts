import { pool } from '../db.js';
import type { RiskProvider } from '../providers/risk-provider.js';

export async function runProviderRiskCheck(provider: RiskProvider, input: { userId: string; amountMinor: bigint; currency: string; transactionId?: string }) {
  const result = await provider.screenTransaction(input);
  await pool.query(`INSERT INTO risk_checks(user_id,transaction_id,provider_name,decision,provider_reference,reason,raw) VALUES($1,$2,$3,$4,$5,$6,$7)`, [input.userId, input.transactionId ?? null, provider.constructor.name, result.decision, result.providerReference, result.reason ?? null, JSON.stringify(result.raw ?? {})]);
  return result;
}
