import type { PoolClient } from 'pg';

export async function getAvailableBalance(client: PoolClient, ledgerAccountId: string): Promise<bigint> {
  const r = await client.query<{ balance: string }>(
    `SELECT COALESCE(SUM(CASE WHEN entry_type='CREDIT' THEN amount_minor ELSE -amount_minor END),0)::text AS balance
     FROM ledger_entries WHERE ledger_account_id=$1`, [ledgerAccountId]
  );
  return BigInt(r.rows[0]?.balance ?? '0');
}

export async function postDoubleEntry(
  client: PoolClient,
  txId: string,
  debitAccountId: string,
  creditAccountId: string,
  amountMinor: bigint,
  options: { checkDebitBalance?: boolean } = {}
): Promise<void> {
  if (amountMinor <= 0n) throw new Error('amount must be positive');
  const ids = [debitAccountId, creditAccountId].sort();
  await client.query('SELECT id FROM ledger_accounts WHERE id = ANY($1::uuid[]) FOR UPDATE', [ids]);
  const balance = await getAvailableBalance(client, debitAccountId);
  if (options.checkDebitBalance !== false && balance < amountMinor) throw new Error('INSUFFICIENT_FUNDS');

  await client.query(
    `INSERT INTO ledger_entries(transaction_id, ledger_account_id, entry_type, amount_minor)
     VALUES ($1,$2,'DEBIT',$3),($1,$4,'CREDIT',$3)`,
    [txId, debitAccountId, amountMinor.toString(), creditAccountId]
  );
}
