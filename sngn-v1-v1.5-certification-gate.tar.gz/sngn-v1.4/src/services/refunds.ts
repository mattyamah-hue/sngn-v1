import { randomUUID } from 'node:crypto';
import { withTx } from '../db.js';
import { postDoubleEntry } from './ledger.js';

export async function refundTransfer(input:{ originalTransactionId:string; actorId:string; amountMinor:bigint; idempotencyKey:string }) {
  return withTx(async client => {
    const existing = await client.query(`SELECT id,status FROM transactions WHERE idempotency_key=$1`, [input.idempotencyKey]);
    if (existing.rowCount) return existing.rows[0];
    const original = await client.query<{sender_ledger_account_id:string;recipient_ledger_account_id:string;amount_minor:string;status:string}>(
      `SELECT sender_ledger_account_id,recipient_ledger_account_id,amount_minor,status FROM transactions WHERE id=$1 FOR UPDATE`, [input.originalTransactionId]);
    if (!original.rowCount) throw new Error('TRANSACTION_NOT_FOUND');
    if (original.rows[0].status !== 'SETTLED') throw new Error('ORIGINAL_NOT_SETTLED');
    const max = BigInt(original.rows[0].amount_minor);
    if (input.amountMinor <= 0n || input.amountMinor > max) throw new Error('INVALID_REFUND_AMOUNT');
    const txId = randomUUID();
    await client.query(`INSERT INTO transactions(id,idempotency_key,type,status,currency,amount_minor,sender_ledger_account_id,recipient_ledger_account_id,metadata) VALUES($1,$2,'REFUND','POSTING','SNGN',$3,$4,$5,$6)`, [txId,input.idempotencyKey,input.amountMinor.toString(),original.rows[0].recipient_ledger_account_id,original.rows[0].sender_ledger_account_id,JSON.stringify({originalTransactionId:input.originalTransactionId})]);
    await postDoubleEntry(client,txId,original.rows[0].recipient_ledger_account_id,original.rows[0].sender_ledger_account_id,input.amountMinor);
    await client.query(`UPDATE transactions SET status='SETTLED',settled_at=now() WHERE id=$1`,[txId]);
    await client.query(`INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'REFUND_SETTLED',$3)`,[txId,input.actorId,JSON.stringify({originalTransactionId:input.originalTransactionId})]);
    return {id:txId,status:'SETTLED',originalTransactionId:input.originalTransactionId};
  });
}
