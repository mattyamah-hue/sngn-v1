import { withTx } from '../db.js';

export async function runSandboxReconciliation(input: { externalAmountMinor: bigint; providerName?: string }) {
  return withTx(async client => {
    const r = await client.query<{ amount: string }>(
      `SELECT COALESCE(SUM(CASE
          WHEN la.code='SNGN_BACKING_ASSET' AND le.entry_type='DEBIT' THEN le.amount_minor
          WHEN la.code='SNGN_BACKING_ASSET' AND le.entry_type='CREDIT' THEN -le.amount_minor
          WHEN la.code='SNGN_REDEMPTION_ASSET' AND le.entry_type='CREDIT' THEN -le.amount_minor
          WHEN la.code='SNGN_REDEMPTION_ASSET' AND le.entry_type='DEBIT' THEN le.amount_minor
          ELSE 0 END),0)::text AS amount
       FROM ledger_entries le JOIN ledger_accounts la ON la.id=le.ledger_account_id
       WHERE la.code IN ('SNGN_BACKING_ASSET','SNGN_REDEMPTION_ASSET')`
    );
    const internal = BigInt(r.rows[0]?.amount ?? '0');
    const difference = internal - input.externalAmountMinor;
    const status = difference === 0n ? 'RECONCILED' : 'EXCEPTION';
    const result = await client.query<{ id: string }>(
      `INSERT INTO reconciliation_runs(provider_name,internal_amount_minor,external_amount_minor,difference_minor,status)
       VALUES($1,$2,$3,$4,$5) RETURNING id`,
      [input.providerName ?? 'SANDBOX', internal.toString(), input.externalAmountMinor.toString(), difference.toString(), status]
    );
    if (status === 'EXCEPTION') {
      await client.query(`INSERT INTO reconciliation_exceptions(run_id,difference_minor,reason) VALUES($1,$2,$3)`, [result.rows[0].id,difference.toString(),'INTERNAL_EXTERNAL_POSITION_MISMATCH']);
    }
    return { runId: result.rows[0].id, internalAmountMinor: internal.toString(), externalAmountMinor: input.externalAmountMinor.toString(), differenceMinor: difference.toString(), status };
  });
}
