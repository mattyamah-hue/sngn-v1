import { pool } from '../db.js';

export async function generateSandboxEvidence(scenario: string) {
  const tx = await pool.query(`SELECT id,type,status,amount_minor,currency,created_at,settled_at FROM transactions ORDER BY created_at DESC LIMIT 100`);
  const ledger = await pool.query(`SELECT le.transaction_id,la.code,le.entry_type,le.amount_minor FROM ledger_entries le JOIN ledger_accounts la ON la.id=le.ledger_account_id ORDER BY le.created_at DESC LIMIT 200`);
  const webhooks = await pool.query(`SELECT provider_name,event_id,event_type,signature_valid,processed_at,created_at FROM webhook_events ORDER BY created_at DESC LIMIT 100`);
  const reconciliations = await pool.query(`SELECT * FROM reconciliation_runs ORDER BY created_at DESC LIMIT 50`);
  const artifact = {
    generatedAt: new Date().toISOString(), scenario,
    transactions: tx.rows,
    ledgerEntries: ledger.rows,
    webhookEvents: webhooks.rows,
    reconciliationRuns: reconciliations.rows
  };
  const passed = tx.rows.some((x:any)=>x.status==='SETTLED') && ledger.rows.length > 0;
  const status = passed ? 'PASS' : 'INCOMPLETE';
  const result = await pool.query<{id:string}>(`INSERT INTO sandbox_evidence_runs(scenario,status,summary,artifact) VALUES($1,$2,$3,$4) RETURNING id`, [scenario,status,JSON.stringify({transactionCount:tx.rowCount,ledgerEntryCount:ledger.rowCount}),JSON.stringify(artifact)]);
  return { id: result.rows[0].id, status, artifact };
}
