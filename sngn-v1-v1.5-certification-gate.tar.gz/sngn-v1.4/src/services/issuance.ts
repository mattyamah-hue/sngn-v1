import { randomUUID } from 'node:crypto';
import { withTx } from '../db.js';
import { postDoubleEntry } from './ledger.js';
import type { PaymentProvider } from '../providers/payment-provider.js';

export async function fundAndIssue(input: {
  userId: string;
  walletId: string;
  ledgerAccountId: string;
  amountMinor: bigint;
  provider: PaymentProvider;
}) {
  const kyc = await (await import('../db.js')).pool.query<{ kyc_status: string; status: string }>(
    `SELECT kyc_status, status FROM users WHERE id=$1`, [input.userId]
  );
  if (!kyc.rowCount) throw new Error('USER_NOT_FOUND');
  if (kyc.rows[0].status !== 'ACTIVE') throw new Error('ACCOUNT_NOT_ACTIVE');
  if (kyc.rows[0].kyc_status !== 'VERIFIED') throw new Error('KYC_REQUIRED');

  const providerResult = await input.provider.createFunding({ amountMinor: input.amountMinor, customerId: input.userId });
  if (providerResult.status !== 'CONFIRMED') throw new Error('FUNDING_PENDING');

  return withTx(async client => {
    const existing = await client.query<{ id: string; status: string }>(
      `SELECT id,status FROM funding_requests WHERE provider_reference=$1`, [providerResult.reference]
    );
    if (existing.rowCount) return existing.rows[0];

    const fundingId = randomUUID();
    const txId = randomUUID();
    const backing = await client.query<{ id: string }>(`SELECT id FROM ledger_accounts WHERE code='SNGN_BACKING_ASSET' FOR UPDATE`);
    if (!backing.rowCount) throw new Error('BACKING_ACCOUNT_NOT_CONFIGURED');

    await client.query(
      `INSERT INTO funding_requests(id,user_id,wallet_id,amount_minor,status,provider_reference,transaction_id,confirmed_at)
       VALUES($1,$2,$3,$4,'CONFIRMED',$5,$6,now())`,
      [fundingId, input.userId, input.walletId, input.amountMinor.toString(), providerResult.reference, txId]
    );
    await client.query(
      `INSERT INTO transactions(id,idempotency_key,type,status,currency,amount_minor,sender_ledger_account_id,recipient_ledger_account_id,external_reference)
       VALUES($1,$2,'ISSUANCE','POSTING','SNGN',$3,$4,$5,$6)`,
      [txId, `funding:${providerResult.reference}`, input.amountMinor.toString(), backing.rows[0].id, input.ledgerAccountId, providerResult.reference]
    );
    await postDoubleEntry(client, txId, backing.rows[0].id, input.ledgerAccountId, input.amountMinor, { checkDebitBalance: false });
    await client.query(`UPDATE transactions SET status='SETTLED', settled_at=now() WHERE id=$1`, [txId]);
    await client.query(`INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'ISSUANCE_SETTLED',$3)`,
      [txId, input.userId, JSON.stringify({ fundingId, providerReference: providerResult.reference, amountMinor: input.amountMinor.toString() })]);
    return { fundingId, transactionId: txId, status: 'SETTLED', providerReference: providerResult.reference };
  });
}
