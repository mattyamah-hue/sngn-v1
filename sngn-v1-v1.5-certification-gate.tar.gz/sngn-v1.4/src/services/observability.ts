import { pool } from '../db.js';

export async function recordEvent(eventName:string, severity:'INFO'|'WARN'|'ERROR'|'CRITICAL', data:Record<string,unknown>={}, durationMs?:number, correlationId?:string) {
  await pool.query(`INSERT INTO observability_events(event_name,severity,duration_ms,correlation_id,data) VALUES($1,$2,$3,$4,$5)`, [eventName,severity,durationMs ?? null,correlationId ?? null,JSON.stringify(data)]);
}

export async function metricsSnapshot() {
  const [tx, errors, reconciliations] = await Promise.all([
    pool.query<{status:string;count:string}>(`SELECT status,count(*)::text count FROM transactions GROUP BY status`),
    pool.query<{severity:string;count:string}>(`SELECT severity,count(*)::text count FROM observability_events WHERE created_at >= now()-interval '24 hours' GROUP BY severity`),
    pool.query<{status:string;count:string}>(`SELECT status,count(*)::text count FROM reconciliation_runs WHERE created_at >= now()-interval '24 hours' GROUP BY status`)
  ]);
  return { transactions: tx.rows, events24h: errors.rows, reconciliation24h: reconciliations.rows };
}
