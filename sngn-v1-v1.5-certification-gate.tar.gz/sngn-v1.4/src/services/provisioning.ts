import { randomUUID } from 'node:crypto';
import { generateApiKey, hashApiKey } from '../auth.js';
import { withTx } from '../db.js';

export async function provisionUser(input: { email: string; displayName: string; kind: 'CUSTOMER' | 'MERCHANT' }) {
  return withTx(async client => {
    const userId = randomUUID();
    const walletId = randomUUID();
    const ledgerId = randomUUID();
    const code = `${input.kind}_${userId.replaceAll('-', '')}`;
    const apiKey = generateApiKey();

    await client.query(
      `INSERT INTO users(id,email,display_name,kind) VALUES($1,$2,$3,$4)`,
      [userId, input.email, input.displayName, input.kind]
    );
    await client.query(
      `INSERT INTO wallets(id,owner_id,currency) VALUES($1,$2,'SNGN')`,
      [walletId, userId]
    );
    await client.query(
      `INSERT INTO ledger_accounts(id,wallet_id,code,kind,currency) VALUES($1,$2,$3,$4,'SNGN')`,
      [ledgerId, walletId, code, input.kind]
    );
    await client.query(
      `INSERT INTO api_credentials(user_id,key_prefix,key_hash) VALUES($1,$2,$3)`,
      [userId, apiKey.slice(0, 13), hashApiKey(apiKey)]
    );
    await client.query(`INSERT INTO account_limits(owner_id) VALUES($1) ON CONFLICT DO NOTHING`, [userId]);
    await client.query(`INSERT INTO risk_profiles(user_id) VALUES($1) ON CONFLICT DO NOTHING`, [userId]);

    return { userId, walletId, ledgerAccountId: ledgerId, apiKey };
  });
}
