import { createHash, randomUUID } from 'node:crypto';
import type { FastifyRequest } from 'fastify';
import { pool } from '../db.js';

export function hashIdentifier(value: string | undefined) {
  if (!value) return null;
  return createHash('sha256').update(value).digest('hex');
}

export async function recordSecurityEvent(input:{request:FastifyRequest;actorId?:string;eventType:string;severity:'INFO'|'LOW'|'MEDIUM'|'HIGH'|'CRITICAL';metadata?:Record<string,unknown>}) {
  const requestId = String(input.request.id ?? randomUUID());
  await pool.query(`INSERT INTO security_events(actor_id,event_type,severity,request_id,ip_hash,user_agent_hash,metadata) VALUES($1,$2,$3,$4,$5,$6,$7)`, [input.actorId ?? null,input.eventType,input.severity,requestId,hashIdentifier(input.request.ip),hashIdentifier(input.request.headers['user-agent'] as string|undefined),JSON.stringify(input.metadata ?? {})]);
}
