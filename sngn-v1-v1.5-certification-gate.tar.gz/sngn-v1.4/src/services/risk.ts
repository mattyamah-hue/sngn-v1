import type { PoolClient } from 'pg';

export type RiskResult = { decision: 'ALLOW'|'BLOCK'|'REVIEW'; reason?: string };

export async function evaluateRisk(client: PoolClient, userId: string, amountMinor: bigint): Promise<RiskResult> {
  const r = await client.query<{ decision: 'ALLOW'|'BLOCK'|'REVIEW'; reason: string|null }>(
    `SELECT decision, reason FROM risk_profiles WHERE user_id=$1`, [userId]
  );
  const profile = r.rows[0];
  if (profile?.decision === 'BLOCK') return { decision: 'BLOCK', reason: profile.reason ?? 'RISK_PROFILE_BLOCK' };
  if (profile?.decision === 'REVIEW') return { decision: 'REVIEW', reason: profile.reason ?? 'RISK_PROFILE_REVIEW' };
  if (amountMinor <= 0n) return { decision: 'BLOCK', reason: 'INVALID_AMOUNT' };
  return { decision: 'ALLOW' };
}
