import { randomUUID } from 'node:crypto';
import { withTx } from '../db.js';
import { postDoubleEntry } from './ledger.js';
import { enforceTransferLimits } from './limits.js';
import { evaluateRisk } from './risk.js';
import { transferableMetadata } from '../domain/transferability.js';

export type TransferInput = {
  idempotencyKey: string;
  senderLedgerAccountId: string;
  recipientLedgerAccountId: string;
  amountMinor: bigint;
  actorId?: string;
  metadata?: Record<string, unknown>;
};

export async function createTransfer(input: TransferInput) {
  return withTx(async client => {
    const existing = await client.query<{ id: string; status: string }>(
      'SELECT id,status FROM transactions WHERE idempotency_key=$1', [input.idempotencyKey]
    );
    if (existing.rowCount) return existing.rows[0];

    if (input.senderLedgerAccountId === input.recipientLedgerAccountId) throw new Error('SAME_ACCOUNT');
    if (!input.actorId) throw new Error('ACTOR_REQUIRED');
    const kyc = await client.query<{kyc_status:string}>(`SELECT kyc_status FROM users WHERE id=$1 FOR SHARE`, [input.actorId]);
    if (!kyc.rowCount) throw new Error('USER_NOT_FOUND');
    if (kyc.rows[0].kyc_status !== 'VERIFIED') throw new Error('KYC_REQUIRED');
    const accounts = await client.query<{ id: string; status: string; currency: string }>(
      `SELECT id,status,currency FROM ledger_accounts WHERE id = ANY($1::uuid[]) FOR UPDATE`,
      [[input.senderLedgerAccountId, input.recipientLedgerAccountId]]
    );
    if (accounts.rowCount !== 2) throw new Error('ACCOUNT_NOT_FOUND');
    if (accounts.rows.some(a => a.status !== 'ACTIVE')) throw new Error('ACCOUNT_NOT_ACTIVE');
    if (accounts.rows.some(a => a.currency !== 'SNGN')) throw new Error('CURRENCY_MISMATCH');
    await enforceTransferLimits(client, input.actorId ?? '', input.amountMinor);
    const risk = await evaluateRisk(client, input.actorId ?? '', input.amountMinor);
    if (risk.decision === 'BLOCK') throw new Error(risk.reason ?? 'RISK_BLOCKED');
    if (risk.decision === 'REVIEW') throw new Error('REQUIRES_REVIEW');
    const txId = randomUUID();
    await client.query(
      `INSERT INTO transactions(id,idempotency_key,type,status,currency,amount_minor,sender_ledger_account_id,recipient_ledger_account_id,metadata)
       VALUES($1,$2,'TRANSFER','AUTHORIZED','SNGN',$3,$4,$5,$6)`,
      [txId, input.idempotencyKey, input.amountMinor.toString(), input.senderLedgerAccountId, input.recipientLedgerAccountId, JSON.stringify(transferableMetadata(input.metadata ?? {}))]
    );

    try {
      await client.query(`UPDATE transactions SET status='POSTING' WHERE id=$1`, [txId]);
      await postDoubleEntry(client, txId, input.senderLedgerAccountId, input.recipientLedgerAccountId, input.amountMinor);
      await client.query(`UPDATE transactions SET status='SETTLED', settled_at=now() WHERE id=$1`, [txId]);
      await client.query(
        `INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'TRANSFER_SETTLED',$3)`,
        [txId, input.actorId ?? null, JSON.stringify({ amountMinor: input.amountMinor.toString() })]
      );
      return { id: txId, status: 'SETTLED' };
    } catch (e) {
      const message = e instanceof Error ? e.message : 'TRANSFER_FAILED';
      await client.query(`UPDATE transactions SET status='FAILED', failure_code=$2 WHERE id=$1`, [txId, message]);
      throw e;
    }
  });
}
