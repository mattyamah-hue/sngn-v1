import { pool } from '../db.js';
import { runSandboxReconciliation } from './reconciliation.js';
import { recordEvent } from './observability.js';

export async function runReconciliationJob(input: { providerName: string; externalAmountMinor: bigint }) {
  const job = await pool.query<{id:string}>(`INSERT INTO reconciliation_jobs(provider_name) VALUES($1) RETURNING id`, [input.providerName]);
  const jobId = job.rows[0].id;
  try {
    const run = await runSandboxReconciliation(input);
    await pool.query(`UPDATE reconciliation_jobs SET status='COMPLETED', completed_at=now(), run_id=$2 WHERE id=$1`, [jobId, run.runId]);
    await recordEvent('RECONCILIATION_JOB_COMPLETED', run.status === 'RECONCILED' ? 'INFO' : 'WARN', { jobId, ...run });
    return { jobId, ...run };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'UNKNOWN';
    await pool.query(`UPDATE reconciliation_jobs SET status='FAILED', completed_at=now(), error=$2 WHERE id=$1`, [jobId, message]);
    await recordEvent('RECONCILIATION_JOB_FAILED', 'ERROR', { jobId, error: message });
    throw error;
  }
}

export function startReconciliationWorker() {
  const intervalMs = Number(process.env.RECONCILIATION_INTERVAL_MS ?? 300000);
  if (process.env.ENABLE_RECONCILIATION_WORKER !== 'true') return () => undefined;
  const timer = setInterval(async () => {
    const external = process.env.SANDBOX_EXTERNAL_POSITION_MINOR;
    if (!external) return;
    try { await runReconciliationJob({ providerName: process.env.SANDBOX_PROVIDER_NAME ?? 'SANDBOX', externalAmountMinor: BigInt(external) }); }
    catch { /* failure is persisted and observable */ }
  }, intervalMs);
  timer.unref();
  return () => clearInterval(timer);
}
