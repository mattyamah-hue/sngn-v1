import type { PoolClient } from 'pg';

export async function enforceTransferLimits(client: PoolClient, userId: string, amountMinor: bigint) {
  const lim = await client.query<{ single_tx_limit_minor: string; daily_limit_minor: string }>(
    `SELECT single_tx_limit_minor, daily_limit_minor FROM account_limits WHERE owner_id=$1 FOR UPDATE`, [userId]
  );
  if (!lim.rowCount) return;
  const single = BigInt(lim.rows[0].single_tx_limit_minor);
  const daily = BigInt(lim.rows[0].daily_limit_minor);
  if (amountMinor > single) throw new Error('SINGLE_TRANSACTION_LIMIT');
  const spent = await client.query<{ total: string }>(
    `SELECT COALESCE(SUM(amount_minor),0)::text total FROM transactions
      WHERE sender_ledger_account_id IN (SELECT la.id FROM ledger_accounts la JOIN wallets w ON w.id=la.wallet_id WHERE w.owner_id=$1)
        AND type='TRANSFER' AND status='SETTLED' AND created_at >= date_trunc('day', now())`, [userId]
  );
  if (BigInt(spent.rows[0]?.total ?? '0') + amountMinor > daily) throw new Error('DAILY_TRANSACTION_LIMIT');
}
