import { randomUUID } from 'node:crypto';
import { withTx } from '../db.js';
import { postDoubleEntry } from './ledger.js';
import type { PaymentProvider } from '../providers/payment-provider.js';

export async function redeem(input: {
  userId: string;
  walletId: string;
  ledgerAccountId: string;
  amountMinor: bigint;
  bankCode: string;
  accountNumber: string;
  provider: PaymentProvider;
}) {
  const kyc = await (await import('../db.js')).pool.query<{ kyc_status: string; status: string }>(
    `SELECT kyc_status, status FROM users WHERE id=$1`, [input.userId]
  );
  if (!kyc.rowCount) throw new Error('USER_NOT_FOUND');
  if (kyc.rows[0].status !== 'ACTIVE') throw new Error('ACCOUNT_NOT_ACTIVE');
  if (kyc.rows[0].kyc_status !== 'VERIFIED') throw new Error('KYC_REQUIRED');

  const payout = await input.provider.createPayout({ amountMinor: input.amountMinor, bankCode: input.bankCode, accountNumber: input.accountNumber });
  if (payout.status !== 'CONFIRMED') throw new Error('PAYOUT_PENDING');

  return withTx(async client => {
    const existing = await client.query<{ id: string; status: string }>(
      `SELECT id,status FROM redemption_requests WHERE provider_reference=$1`, [payout.reference]
    );
    if (existing.rowCount) return existing.rows[0];

    const control = await client.query<{ id: string }>(`SELECT id FROM ledger_accounts WHERE code='SNGN_REDEMPTION_ASSET' FOR UPDATE`);
    if (!control.rowCount) throw new Error('REDEMPTION_ACCOUNT_NOT_CONFIGURED');

    const redemptionId = randomUUID();
    const txId = randomUUID();
    await client.query(
      `INSERT INTO redemption_requests(id,user_id,wallet_id,amount_minor,status,bank_code,account_number,provider_reference,transaction_id,confirmed_at)
       VALUES($1,$2,$3,$4,'CONFIRMED',$5,$6,$7,$8,now())`,
      [redemptionId, input.userId, input.walletId, input.amountMinor.toString(), input.bankCode, input.accountNumber, payout.reference, txId]
    );
    await client.query(
      `INSERT INTO transactions(id,idempotency_key,type,status,currency,amount_minor,sender_ledger_account_id,recipient_ledger_account_id,external_reference)
       VALUES($1,$2,'REDEMPTION','POSTING','SNGN',$3,$4,$5,$6)`,
      [txId, `redemption:${payout.reference}`, input.amountMinor.toString(), input.ledgerAccountId, control.rows[0].id, payout.reference]
    );
    await postDoubleEntry(client, txId, input.ledgerAccountId, control.rows[0].id, input.amountMinor);
    await client.query(`UPDATE transactions SET status='SETTLED', settled_at=now() WHERE id=$1`, [txId]);
    await client.query(`INSERT INTO audit_events(transaction_id,actor_id,event_type,data) VALUES($1,$2,'REDEMPTION_SETTLED',$3)`,
      [txId, input.userId, JSON.stringify({ redemptionId, providerReference: payout.reference, amountMinor: input.amountMinor.toString() })]);
    return { redemptionId, transactionId: txId, status: 'SETTLED', providerReference: payout.reference };
  });
}
