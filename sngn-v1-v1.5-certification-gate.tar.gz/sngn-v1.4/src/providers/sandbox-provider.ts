import type { AccountVerification, PaymentProvider } from './payment-provider.js';
import { randomUUID } from 'node:crypto';

export class SandboxProvider implements PaymentProvider {
  async verifyAccount(bankCode: string, accountNumber: string): Promise<AccountVerification> {
    return {
      verified: true,
      accountName: 'SUPERMARKET ABC LTD',
      bankName: bankCode || 'Sandbox Bank',
      maskedAccountNumber: `******${accountNumber.slice(-4)}`,
      providerReference: `SANDBOX-VERIFY-${randomUUID()}`
    };
  }

  async createFunding(): Promise<{ reference: string; status: 'PENDING' | 'CONFIRMED' }> {
    return { reference: `SANDBOX-FUND-${randomUUID()}`, status: 'CONFIRMED' };
  }

  async getFundingStatus(): Promise<'PENDING' | 'CONFIRMED' | 'FAILED'> { return 'CONFIRMED'; }

  async createPayout(): Promise<{ reference: string; status: 'PENDING' | 'CONFIRMED' }> {
    return { reference: `SANDBOX-PAYOUT-${randomUUID()}`, status: 'CONFIRMED' };
  }

  async getPayoutStatus(): Promise<'PENDING' | 'CONFIRMED' | 'FAILED'> { return 'CONFIRMED'; }
}
