export type KycResult = {
  decision: 'VERIFIED' | 'PENDING' | 'RESTRICTED' | 'REJECTED';
  providerReference: string;
  raw?: Record<string, unknown>;
};

export interface KycProvider {
  verifyIdentity(input: { userId: string; fullName: string; email: string }): Promise<KycResult>;
}

export class SandboxKycProvider implements KycProvider {
  async verifyIdentity(input: { userId: string; fullName: string; email: string }): Promise<KycResult> {
    return {
      decision: 'VERIFIED',
      providerReference: `SANDBOX-KYC-${input.userId}`,
      raw: { simulated: true, email: input.email }
    };
  }
}
