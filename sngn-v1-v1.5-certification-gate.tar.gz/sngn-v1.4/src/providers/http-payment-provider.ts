import type { AccountVerification, PaymentProvider } from './payment-provider.js';

/** Generic signed/credentialed HTTP adapter. Configure only against an authorized provider sandbox. */
export class HttpPaymentProvider implements PaymentProvider {
  constructor(private readonly baseUrl: string, private readonly apiKey: string) {}
  private async call<T>(path:string, body:unknown):Promise<T> {
    const res = await fetch(`${this.baseUrl.replace(/\/$/,'')}${path}`, { method:'POST', headers:{'content-type':'application/json','authorization':`Bearer ${this.apiKey}`}, body:JSON.stringify(body) });
    if (!res.ok) throw new Error(`PROVIDER_HTTP_${res.status}`);
    return await res.json() as T;
  }
  verifyAccount(bankCode:string, accountNumber:string) { return this.call<AccountVerification>('/accounts/verify',{bankCode,accountNumber}); }
  createFunding(input:{amountMinor:bigint;customerId:string}) { return this.call<{reference:string;status:'PENDING'|'CONFIRMED'}>('/funding',{amountMinor:input.amountMinor.toString(),customerId:input.customerId}); }
  getFundingStatus(reference:string) { return this.call<{status:'PENDING'|'CONFIRMED'|'FAILED'}>('/funding/status',{reference}).then(x=>x.status); }
  createPayout(input:{amountMinor:bigint;bankCode:string;accountNumber:string}) { return this.call<{reference:string;status:'PENDING'|'CONFIRMED'}>('/payouts',{amountMinor:input.amountMinor.toString(),bankCode:input.bankCode,accountNumber:input.accountNumber}); }
  getPayoutStatus(reference:string) { return this.call<{status:'PENDING'|'CONFIRMED'|'FAILED'}>('/payouts/status',{reference}).then(x=>x.status); }
}
