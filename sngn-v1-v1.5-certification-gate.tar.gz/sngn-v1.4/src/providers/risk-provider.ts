export type RiskResult = {
  decision: 'ALLOW' | 'REVIEW' | 'BLOCK';
  providerReference: string;
  reason?: string;
  raw?: Record<string, unknown>;
};

export interface RiskProvider {
  screenTransaction(input: { userId: string; amountMinor: bigint; currency: string; transactionId?: string }): Promise<RiskResult>;
}

export class SandboxRiskProvider implements RiskProvider {
  async screenTransaction(input: { userId: string; amountMinor: bigint; currency: string; transactionId?: string }): Promise<RiskResult> {
    return {
      decision: 'ALLOW',
      providerReference: `SANDBOX-RISK-${input.transactionId ?? input.userId}`,
      raw: { simulated: true, amountMinor: input.amountMinor.toString(), currency: input.currency }
    };
  }
}
