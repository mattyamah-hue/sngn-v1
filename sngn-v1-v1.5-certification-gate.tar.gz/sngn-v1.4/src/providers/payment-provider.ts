export type AccountVerification = {
  verified: boolean;
  accountName?: string;
  bankName?: string;
  maskedAccountNumber?: string;
  providerReference: string;
};

export interface PaymentProvider {
  verifyAccount(bankCode: string, accountNumber: string): Promise<AccountVerification>;
  createFunding(input: { amountMinor: bigint; customerId: string }): Promise<{ reference: string; status: 'PENDING' | 'CONFIRMED' }>;
  getFundingStatus(reference: string): Promise<'PENDING' | 'CONFIRMED' | 'FAILED'>;
  createPayout(input: { amountMinor: bigint; bankCode: string; accountNumber: string }): Promise<{ reference: string; status: 'PENDING' | 'CONFIRMED' }>;
  getPayoutStatus(reference: string): Promise<'PENDING' | 'CONFIRMED' | 'FAILED'>;
}
