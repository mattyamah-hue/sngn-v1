import { createHmac, timingSafeEqual } from 'node:crypto';
import type { FastifyRequest } from 'fastify';
import { pool } from './db.js';

export function verifyWebhookSignature(rawBody:string, signature:string, secret:string) {
  const expected = createHmac('sha256',secret).update(rawBody).digest('hex');
  const a = Buffer.from(expected); const b = Buffer.from(signature);
  return a.length === b.length && timingSafeEqual(a,b);
}

export async function processWebhook(input:{providerName:string;eventId:string;eventType:string;signatureValid:boolean;payload:Record<string,unknown>}) {
  const inserted = await pool.query<{id:string}>(`INSERT INTO webhook_events(provider_name,event_id,event_type,signature_valid,payload) VALUES($1,$2,$3,$4,$5) ON CONFLICT(provider_name,event_id) DO NOTHING RETURNING id`, [input.providerName,input.eventId,input.eventType,input.signatureValid,JSON.stringify(input.payload)]);
  if (!inserted.rowCount) return { duplicate:true };
  if (!input.signatureValid) throw new Error('INVALID_WEBHOOK_SIGNATURE');
  await pool.query(`UPDATE webhook_events SET processed_at=now() WHERE id=$1`,[inserted.rows[0].id]);
  return { duplicate:false, processed:true };
}

export async function rawBody(request:FastifyRequest) {
  return JSON.stringify(request.body ?? {});
}
