import { createHash, randomBytes } from 'node:crypto';
import type { FastifyRequest } from 'fastify';
import { pool } from './db.js';

export function hashApiKey(key: string): string {
  return createHash('sha256').update(key).digest('hex');
}

export function generateApiKey(): string {
  return `sngn_${randomBytes(32).toString('base64url')}`;
}

export async function authenticate(request: FastifyRequest) {
  const header = request.headers.authorization;
  if (!header?.startsWith('Bearer ')) return null;
  const key = header.slice('Bearer '.length).trim();
  if (!key) return null;
  const hash = hashApiKey(key);
  const result = await pool.query<{ user_id: string; status: string; kind: string }>(
    `SELECT c.user_id, c.status, u.kind
       FROM api_credentials c JOIN users u ON u.id=c.user_id
      WHERE c.key_hash=$1 AND c.status='ACTIVE' AND u.status='ACTIVE'`, [hash]
  );
  const credential = result.rows[0];
  if (!credential) return null;
  await pool.query('UPDATE api_credentials SET last_used_at=now() WHERE key_hash=$1', [hash]);
  return { userId: credential.user_id, kind: credential.kind };
}

export async function requireAuth(request: FastifyRequest) {
  const auth = await authenticate(request);
  if (!auth) throw Object.assign(new Error('UNAUTHORIZED'), { statusCode: 401 });
  return auth;
}

export function requireAdminKey(request: FastifyRequest) {
  const expected = process.env.ADMIN_PROVISIONING_KEY;
  const provided = request.headers['x-admin-key'];
  if (!expected || typeof provided !== 'string' || provided !== expected) {
    throw Object.assign(new Error('ADMIN_AUTH_REQUIRED'), { statusCode: 401 });
  }
}
