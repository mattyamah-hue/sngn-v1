import Fastify from 'fastify';
import sensible from '@fastify/sensible';
import 'dotenv/config';
import { registerRoutes } from './http/routes.js';
import { registerV12Routes } from './http/v12-routes.js';
import { registerV13Routes } from './http/v13-routes.js';
import { startReconciliationWorker } from './services/reconciliation-worker.js';

const app = Fastify({ logger: true, bodyLimit: 256 * 1024, requestIdHeader: 'x-request-id' });
await app.register(sensible);
await registerRoutes(app);
await registerV12Routes(app);
await registerV13Routes(app);
startReconciliationWorker();

app.addHook('onRequest', async (request) => {
  request.headers['x-request-id'] = request.id;
});

app.addHook('onResponse', async (request, reply) => {
  try {
    const { pool } = await import('./db.js');
    await pool.query(`INSERT INTO api_request_events(request_id,method,route,status_code,duration_ms) VALUES($1,$2,$3,$4,$5)`, [request.id,request.method,request.routeOptions.url,reply.statusCode,Math.max(0,Math.round(reply.elapsedTime))]);
  } catch {}
});

const port = Number(process.env.PORT ?? 3000);
await app.listen({ port, host: '0.0.0.0' });

const shutdown = async () => { await app.close(); process.exit(0); };
process.once('SIGTERM', shutdown);
process.once('SIGINT', shutdown);
