import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAdminKey, requireAuth } from '../auth.js';
import { SandboxKycProvider } from '../providers/kyc-provider.js';
import { SandboxRiskProvider } from '../providers/risk-provider.js';
import { runKycCheck } from '../services/kyc.js';
import { runProviderRiskCheck } from '../services/risk-provider-service.js';
import { runReconciliationJob } from '../services/reconciliation-worker.js';
import { generateSandboxEvidence } from '../services/evidence.js';

export async function registerV13Routes(app: FastifyInstance) {
  app.post('/v1/kyc/check', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    try { return reply.send(await runKycCheck(new SandboxKycProvider(), auth.userId)); }
    catch (e) { return reply.code(400).send({error:e instanceof Error?e.message:'KYC_FAILED'}); }
  });

  app.post('/v1/admin/risk/screen', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const body=z.object({userId:z.string().uuid(),amountMinor:z.string().regex(/^\d+$/),currency:z.string().default('SNGN'),transactionId:z.string().uuid().optional()}).parse(req.body);
    try { return reply.send(await runProviderRiskCheck(new SandboxRiskProvider(), {...body, amountMinor:BigInt(body.amountMinor)})); }
    catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'RISK_PROVIDER_FAILED'});}
  });

  app.post('/v1/admin/reconciliation/run', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const body=z.object({providerName:z.string().min(1),externalAmountMinor:z.string().regex(/^\d+$/)}).parse(req.body);
    try{return reply.send(await runReconciliationJob({providerName:body.providerName,externalAmountMinor:BigInt(body.externalAmountMinor)}));}
    catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'RECONCILIATION_FAILED'});}
  });

  app.post('/v1/admin/sandbox/evidence', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const body=z.object({scenario:z.string().min(3)}).parse(req.body);
    try{return reply.send(await generateSandboxEvidence(body.scenario));}
    catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'EVIDENCE_FAILED'});}
  });
}
