import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { SandboxProvider } from '../providers/sandbox-provider.js';
import { createTransfer } from '../services/transfer.js';
import { fundAndIssue } from '../services/issuance.js';
import { redeem } from '../services/redemption.js';
import { provisionUser } from '../services/provisioning.js';
import { runSandboxReconciliation } from '../services/reconciliation.js';
import { nairaToMinor, minorToNaira } from '../domain/money.js';
import { pool } from '../db.js';
import { requireAdminKey, requireAuth } from '../auth.js';

const provider = new SandboxProvider();

export async function registerRoutes(app: FastifyInstance) {
  app.get('/health', async () => ({ ok: true, service: 'sngn-v1', version: '1.1.0' }));

  app.post('/v1/provisioning/users', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ email: z.string().email(), displayName: z.string().min(2), kind: z.enum(['CUSTOMER','MERCHANT']).default('CUSTOMER') }).parse(req.body);
    try { return reply.code(201).send(await provisionUser(body)); }
    catch (e) { return reply.code(409).send({ error: e instanceof Error ? e.message : 'PROVISIONING_FAILED' }); }
  });

  app.post('/v1/beneficiaries/verify', async (req, reply) => {
    try { await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ bankCode: z.string().min(1), accountNumber: z.string().regex(/^\d{10}$/) }).parse(req.body);
    return provider.verifyAccount(body.bankCode, body.accountNumber);
  });

  app.get('/v1/wallets/me', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const r = await pool.query<{ wallet_id: string; ledger_account_id: string; balance: string }>(
      `SELECT w.id wallet_id, la.id ledger_account_id,
       COALESCE(SUM(CASE WHEN le.entry_type='CREDIT' THEN le.amount_minor ELSE -le.amount_minor END),0)::text balance
       FROM wallets w JOIN ledger_accounts la ON la.wallet_id=w.id
       LEFT JOIN ledger_entries le ON le.ledger_account_id=la.id
       WHERE w.owner_id=$1 GROUP BY w.id,la.id`, [auth.userId]
    );
    const row = r.rows[0];
    const minor = BigInt(row?.balance ?? '0');
    return { walletId: row?.wallet_id, ledgerAccountId: row?.ledger_account_id, currency: 'SNGN', amountMinor: minor.toString(), amount: minorToNaira(minor) };
  });

  app.get('/v1/wallets/:walletId/balance', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const { walletId } = z.object({ walletId: z.string().uuid() }).parse(req.params);
    const r = await pool.query<{ balance: string }>(
      `SELECT COALESCE(SUM(CASE WHEN le.entry_type='CREDIT' THEN le.amount_minor ELSE -le.amount_minor END),0)::text balance
       FROM wallets w JOIN ledger_accounts la ON la.wallet_id=w.id LEFT JOIN ledger_entries le ON le.ledger_account_id=la.id
       WHERE w.id=$1 AND w.owner_id=$2`, [walletId, auth.userId]
    );
    const minor = BigInt(r.rows[0]?.balance ?? '0');
    return { currency: 'SNGN', amountMinor: minor.toString(), amount: minorToNaira(minor) };
  });

  app.post('/v1/funding', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ amount: z.string().regex(/^\d+(\.\d{1,2})?$/) }).parse(req.body);
    const kyc = await pool.query<{kyc_status:string}>(`SELECT kyc_status FROM users WHERE id=$1`, [auth.userId]);
    if (kyc.rows[0]?.kyc_status !== 'VERIFIED') return reply.code(403).send({ error: 'KYC_REQUIRED' });
    const wallet = await pool.query<{ wallet_id: string; ledger_account_id: string }>(
      `SELECT w.id wallet_id, la.id ledger_account_id FROM wallets w JOIN ledger_accounts la ON la.wallet_id=w.id WHERE w.owner_id=$1`, [auth.userId]
    );
    if (!wallet.rowCount) return reply.code(404).send({ error: 'WALLET_NOT_FOUND' });
    try {
      return reply.code(201).send(await fundAndIssue({ userId: auth.userId, walletId: wallet.rows[0].wallet_id, ledgerAccountId: wallet.rows[0].ledger_account_id, amountMinor: nairaToMinor(body.amount), provider }));
    } catch (e) { const msg = e instanceof Error ? e.message : 'FUNDING_FAILED'; return reply.code(msg === 'FUNDING_PENDING' ? 202 : 400).send({ error: msg }); }
  });

  app.post('/v1/transfers', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ senderLedgerAccountId: z.string().uuid(), recipientLedgerAccountId: z.string().uuid(), amount: z.string(), metadata: z.record(z.unknown()).optional() }).parse(req.body);
    const key = req.headers['idempotency-key'];
    if (typeof key !== 'string' || key.length < 8) return reply.code(400).send({ error: 'Idempotency-Key required' });
    try {
      const owner = await pool.query(`SELECT 1 FROM ledger_accounts la JOIN wallets w ON w.id=la.wallet_id WHERE la.id=$1 AND w.owner_id=$2`, [body.senderLedgerAccountId, auth.userId]);
      if (!owner.rowCount) return reply.code(403).send({ error: 'SENDER_ACCOUNT_NOT_OWNED' });
      const result = await createTransfer({ idempotencyKey: key, senderLedgerAccountId: body.senderLedgerAccountId, recipientLedgerAccountId: body.recipientLedgerAccountId, amountMinor: nairaToMinor(body.amount), actorId: auth.userId, metadata: body.metadata });
      return reply.code(201).send(result);
    } catch (e) { const message = e instanceof Error ? e.message : 'TRANSFER_FAILED'; return reply.code(message === 'INSUFFICIENT_FUNDS' ? 409 : 400).send({ error: message }); }
  });

  app.post('/v1/redemptions', async (req, reply) => {
    let auth; try { auth = await requireAuth(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ amount: z.string().regex(/^\d+(\.\d{1,2})?$/), bankCode: z.string().min(1), accountNumber: z.string().regex(/^\d{10}$/) }).parse(req.body);
    const kyc = await pool.query<{kyc_status:string}>(`SELECT kyc_status FROM users WHERE id=$1`, [auth.userId]);
    if (kyc.rows[0]?.kyc_status !== 'VERIFIED') return reply.code(403).send({ error: 'KYC_REQUIRED' });
    const wallet = await pool.query<{ wallet_id: string; ledger_account_id: string }>(`SELECT w.id wallet_id, la.id ledger_account_id FROM wallets w JOIN ledger_accounts la ON la.wallet_id=w.id WHERE w.owner_id=$1`, [auth.userId]);
    if (!wallet.rowCount) return reply.code(404).send({ error: 'WALLET_NOT_FOUND' });
    try {
      return reply.code(201).send(await redeem({ userId: auth.userId, walletId: wallet.rows[0].wallet_id, ledgerAccountId: wallet.rows[0].ledger_account_id, amountMinor: nairaToMinor(body.amount), bankCode: body.bankCode, accountNumber: body.accountNumber, provider }));
    } catch (e) { const msg = e instanceof Error ? e.message : 'REDEMPTION_FAILED'; return reply.code(msg === 'INSUFFICIENT_FUNDS' ? 409 : 400).send({ error: msg }); }
  });

  app.post('/v1/reconciliation/sandbox', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x = e as Error & { statusCode?: number }; return reply.code(x.statusCode ?? 401).send({ error: x.message }); }
    const body = z.object({ externalAmount: z.string().regex(/^\d+(\.\d{1,2})?$/), providerName: z.string().optional() }).parse(req.body);
    return reply.send(await runSandboxReconciliation({ externalAmountMinor: nairaToMinor(body.externalAmount), providerName: body.providerName }));
  });
}

// V1.2 routes are registered below by the server wrapper to keep the original V1 routes stable.
