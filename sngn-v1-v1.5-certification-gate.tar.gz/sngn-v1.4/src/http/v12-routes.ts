import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { requireAdminKey, requireAuth } from '../auth.js';
import { pool } from '../db.js';
import { nairaToMinor } from '../domain/money.js';
import { openDispute, resolveDispute } from '../services/disputes.js';
import { refundTransfer } from '../services/refunds.js';
import { metricsSnapshot, recordEvent } from '../services/observability.js';
import { processWebhook, verifyWebhookSignature } from '../webhooks.js';
import { applyProviderEvent } from '../services/provider-events.js';
import { openReconciliationException, resolveReconciliationException } from '../services/reconciliation-exceptions.js';

export async function registerV12Routes(app: FastifyInstance) {
  app.get('/v1/observability/metrics', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    return metricsSnapshot();
  });

  app.post('/v1/disputes', async (req, reply) => {
    let auth; try { auth=await requireAuth(req); } catch(e){const x=e as Error & {statusCode?:number};return reply.code(x.statusCode??401).send({error:x.message});}
    const body=z.object({transactionId:z.string().uuid(),reason:z.string().min(3),evidence:z.record(z.unknown()).optional()}).parse(req.body);
    try{return reply.code(201).send(await openDispute({userId:auth.userId,...body}));}catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'DISPUTE_FAILED'});}
  });

  app.post('/v1/admin/disputes/:disputeId/resolve', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const body=z.object({actorId:z.string().uuid(),resolution:z.string().min(3),status:z.enum(['RESOLVED','REJECTED'])}).parse(req.body);
    try{return reply.send(await resolveDispute({disputeId:z.object({disputeId:z.string().uuid()}).parse(req.params).disputeId,...body}));}catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'DISPUTE_RESOLUTION_FAILED'});}
  });

  app.post('/v1/refunds', async (req, reply) => {
    let auth; try { auth=await requireAuth(req); } catch(e){const x=e as Error & {statusCode?:number};return reply.code(x.statusCode??401).send({error:x.message});}
    const body=z.object({originalTransactionId:z.string().uuid(),amount:z.string().regex(/^\d+(\.\d{1,2})?$/)}).parse(req.body);
    const key=req.headers['idempotency-key'];
    if(typeof key!=='string'||key.length<8)return reply.code(400).send({error:'Idempotency-Key required'});
    try{return reply.code(201).send(await refundTransfer({originalTransactionId:body.originalTransactionId,actorId:auth.userId,amountMinor:nairaToMinor(body.amount),idempotencyKey:key}));}catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'REFUND_FAILED'});}
  });

  app.post('/v1/webhooks/:providerName', async (req, reply) => {
    const providerName=z.object({providerName:z.string().min(1).max(64)}).parse(req.params).providerName;
    const eventId=req.headers['x-event-id']; const signature=req.headers['x-signature'];
    if(typeof eventId!=='string'||typeof signature!=='string')return reply.code(400).send({error:'WEBHOOK_HEADERS_REQUIRED'});
    const secret=process.env[`WEBHOOK_SECRET_${providerName.toUpperCase().replace(/[^A-Z0-9]/g,'_')}`] ?? process.env.WEBHOOK_SECRET;
    if(!secret)return reply.code(503).send({error:'WEBHOOK_SECRET_NOT_CONFIGURED'});
    const payload=z.record(z.unknown()).parse(req.body);
    const valid=verifyWebhookSignature(JSON.stringify(payload),signature,secret);
    try {
      if (!valid) { await recordEvent('WEBHOOK_SIGNATURE_REJECTED','WARN',{providerName,eventId}); return reply.code(401).send({error:'INVALID_WEBHOOK_SIGNATURE'}); }
      const result=await applyProviderEvent({providerName,externalEventId:eventId,eventType:String(payload.type??'UNKNOWN'),externalReference:typeof payload.reference==='string'?payload.reference:undefined,amountMinor:typeof payload.amountMinor==='string'?BigInt(payload.amountMinor):undefined,currency:typeof payload.currency==='string'?payload.currency:undefined,payload});
      await recordEvent('WEBHOOK_APPLIED','INFO',{providerName,eventId,eventType:payload.type??'UNKNOWN'});
      return reply.send(result);
    }
    catch(e){ await recordEvent('WEBHOOK_PROCESSING_FAILED','ERROR',{providerName,eventId,error:e instanceof Error?e.message:'UNKNOWN'}); return reply.code(400).send({error:e instanceof Error?e.message:'WEBHOOK_FAILED'}); }
  });

  app.post('/v1/admin/reconciliation/exceptions/:id/resolve', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const params=z.object({id:z.string().uuid()}).parse(req.params);
    const body=z.object({status:z.enum(['RESOLVED','WAIVED']),resolution:z.string().min(3),resolvedBy:z.string().uuid()}).parse(req.body);
    try{return reply.send(await resolveReconciliationException(params.id,body.status,body.resolution,body.resolvedBy));}catch(e){return reply.code(400).send({error:e instanceof Error?e.message:'EXCEPTION_RESOLUTION_FAILED'});}
  });

  app.get('/v1/admin/reconciliation/exceptions', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const r=await pool.query(`SELECT * FROM reconciliation_exceptions ORDER BY opened_at DESC LIMIT 100`); return r.rows;
  });

  app.get('/v1/admin/reconciliation/runs', async (req, reply) => {
    try { requireAdminKey(req); } catch (e) { const x=e as Error & {statusCode?:number}; return reply.code(x.statusCode??401).send({error:x.message}); }
    const r=await pool.query(`SELECT * FROM reconciliation_runs ORDER BY created_at DESC LIMIT 100`); return r.rows;
  });
}
