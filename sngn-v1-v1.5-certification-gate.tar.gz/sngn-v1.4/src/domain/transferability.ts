/**
 * sNGN is network-transferable: a settled amount received by one account may
 * be transferred onward any number of times, subject to the sender's current
 * balance, transaction limits, KYC/risk controls, and account status.
 *
 * "Unlimited hops" does not mean an infinite monetary amount or a bypass of
 * compliance/transaction limits.
 */
export const TRANSFERABILITY = 'NETWORK_TRANSFERABLE' as const;
export type Transferability = typeof TRANSFERABILITY;

export function transferableMetadata(metadata: Record<string, unknown> = {}) {
  return {
    ...metadata,
    transferability: TRANSFERABILITY,
  };
}
