export const CURRENCY = 'SNGN';
export type Minor = bigint;

export function nairaToMinor(naira: string): Minor {
  const match = /^(\d+)(?:\.(\d{1,2}))?$/.exec(naira);
  if (!match) throw new Error('invalid monetary amount');
  const whole = match[1]!;
  const fraction = match[2] ?? '';
  const fractionMinor = (fraction + '00').slice(0, 2);
  return BigInt(whole) * 100n + BigInt(fractionMinor);
}

export function minorToNaira(minor: bigint): string {
  const negative = minor < 0n;
  const value = negative ? -minor : minor;
  return `${negative ? '-' : ''}${value / 100n}.${(value % 100n).toString().padStart(2, '0')}`;
}
