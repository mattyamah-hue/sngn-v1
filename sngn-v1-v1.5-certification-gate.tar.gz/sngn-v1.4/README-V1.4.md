# sNGN V1.4 — Controlled Sandbox Hardening

V1.4 hardens the V1 transaction engine for controlled external testing.

## Included

- Provider webhook verification and idempotent application into funding/redemption state.
- KYC enforcement on funding, transfers and redemption.
- Risk profile enforcement remains inside the transfer transaction path.
- Transaction limits remain enforced before posting.
- Reconciliation exceptions are created automatically on mismatches and can be resolved/waived through an admin workflow.
- Security events and API request telemetry.
- Request IDs, bounded request bodies and graceful shutdown.
- End-to-end sandbox evidence/test-case storage primitives.
- Provider references remain the external correlation mechanism; the internal ledger remains the accounting source of truth.

## Required verification gate

Run with PostgreSQL available:

```bash
npm install
npm run db:migrate
npm run typecheck
npm run build
npm test
```

## Important

The provider adapters are integration contracts. V1.4 does not claim access to live banking/payment rails. Real-money activation requires an appropriate authorized institution/provider arrangement and regulatory permissions.
