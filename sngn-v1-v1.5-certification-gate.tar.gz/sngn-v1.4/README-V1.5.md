# sNGN V1.5 — Certification Test Gate

`npm test` is now the **V1.5 certification gate**. It no longer runs the legacy V1.1 flow test.

The suite executes, against PostgreSQL, the controlled sandbox checks for:

- funding / issuance
- bank-account verification
- A→B→C→D network-transferable value
- transferability metadata (`NETWORK_TRANSFERABLE`)
- idempotency replay
- insufficient funds
- KYC enforcement for funding and redemption
- risk ALLOW / BLOCK / REVIEW
- single-transaction limits
- signed webhook verification and duplicate-event idempotency
- compensating refunds without mutating the original transaction
- dispute open / resolve
- reconciliation match and mismatch/exception resolution
- settled-transaction ledger invariant
- sandbox evidence generation

## Certification command

```bash
npm install
npm run db:migrate
npm run typecheck
npm run build
npm test
```

`npm test` returns a non-zero exit code if any certification case fails.

No test is represented as PASS unless it actually executes against the configured database.
