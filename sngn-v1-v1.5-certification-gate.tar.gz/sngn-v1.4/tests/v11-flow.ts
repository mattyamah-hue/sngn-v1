import { randomUUID } from 'node:crypto';
import { pool } from '../src/db.js';
import { provisionUser } from '../src/services/provisioning.js';
import { fundAndIssue } from '../src/services/issuance.js';
import { createTransfer } from '../src/services/transfer.js';
import { SandboxProvider } from '../src/providers/sandbox-provider.js';

const provider = new SandboxProvider();

async function main() {
  const suffix = randomUUID().slice(0, 8);
  const a = await provisionUser({ email: `alice-${suffix}@example.test`, displayName: 'Alice', kind: 'CUSTOMER' });
  const b = await provisionUser({ email: `merchant-${suffix}@example.test`, displayName: 'Supermarket ABC', kind: 'MERCHANT' });
  const c = await provisionUser({ email: `supplier-${suffix}@example.test`, displayName: 'Supplier XYZ', kind: 'MERCHANT' });

  await fundAndIssue({ userId: a.userId, walletId: a.walletId, ledgerAccountId: a.ledgerAccountId, amountMinor: 10000000n, provider });
  await createTransfer({ idempotencyKey: `a-b-${suffix}`, senderLedgerAccountId: a.ledgerAccountId, recipientLedgerAccountId: b.ledgerAccountId, amountMinor: 10000000n, actorId: a.userId });
  await createTransfer({ idempotencyKey: `b-c-${suffix}`, senderLedgerAccountId: b.ledgerAccountId, recipientLedgerAccountId: c.ledgerAccountId, amountMinor: 4000000n, actorId: b.userId });

  const balances = await pool.query<{ ledger_account_id: string; balance: string }>(
    `SELECT la.id ledger_account_id, COALESCE(SUM(CASE WHEN le.entry_type='CREDIT' THEN le.amount_minor ELSE -le.amount_minor END),0)::text balance
       FROM ledger_accounts la LEFT JOIN ledger_entries le ON le.ledger_account_id=la.id
      WHERE la.id = ANY($1::uuid[]) GROUP BY la.id ORDER BY la.id`, [[a.ledgerAccountId,b.ledgerAccountId,c.ledgerAccountId]]
  );
  const actual = new Map(balances.rows.map(row => [row.ledger_account_id, row.balance]));
  const expected = new Map([[a.ledgerAccountId,'0'],[b.ledgerAccountId,'6000000'],[c.ledgerAccountId,'4000000']]);
  for (const [accountId, expectedBalance] of expected) {
    if (actual.get(accountId) !== expectedBalance) throw new Error(`balance mismatch for ${accountId}: expected ${expectedBalance}, got ${actual.get(accountId)}`);
  }

  const duplicate = await createTransfer({ idempotencyKey: `a-b-${suffix}`, senderLedgerAccountId: a.ledgerAccountId, recipientLedgerAccountId: b.ledgerAccountId, amountMinor: 10000000n, actorId: a.userId });
  if (duplicate.status !== 'SETTLED') throw new Error('idempotency replay did not return settled transaction');
  console.log(JSON.stringify({ ok: true, balances: balances.rows }, null, 2));
}

main().catch(err => { console.error(err); process.exitCode = 1; }).finally(() => pool.end());
