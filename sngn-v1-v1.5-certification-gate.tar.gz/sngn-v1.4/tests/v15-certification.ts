import { randomUUID, createHmac } from 'node:crypto';
import { pool } from '../src/db.js';
import { provisionUser } from '../src/services/provisioning.js';
import { fundAndIssue } from '../src/services/issuance.js';
import { redeem } from '../src/services/redemption.js';
import { createTransfer } from '../src/services/transfer.js';
import { refundTransfer } from '../src/services/refunds.js';
import { openDispute, resolveDispute } from '../src/services/disputes.js';
import { runKycCheck } from '../src/services/kyc.js';
import { runSandboxReconciliation } from '../src/services/reconciliation.js';
import { resolveReconciliationException } from '../src/services/reconciliation-exceptions.js';
import { generateSandboxEvidence } from '../src/services/evidence.js';
import { processWebhook, verifyWebhookSignature } from '../src/webhooks.js';
import { SandboxProvider } from '../src/providers/sandbox-provider.js';
import { SandboxKycProvider } from '../src/providers/kyc-provider.js';
import { TRANSFERABILITY } from '../src/domain/transferability.js';

const provider = new SandboxProvider();
const kycProvider = new SandboxKycProvider();
const suffix = randomUUID().slice(0, 8);
const results: Array<{ name: string; status: 'PASS'|'FAIL'; detail?: string }> = [];

async function check(name: string, fn: () => Promise<void>) {
  try { await fn(); results.push({ name, status: 'PASS' }); console.log(`PASS  ${name}`); }
  catch (e) { const detail = e instanceof Error ? e.message : String(e); results.push({ name, status: 'FAIL', detail }); console.error(`FAIL  ${name}: ${detail}`); }
}

function expect(condition: unknown, message: string): asserts condition { if (!condition) throw new Error(message); }
async function expectError(fn: () => Promise<unknown>, code: string) { try { await fn(); throw new Error(`expected ${code}`); } catch (e) { expect(e instanceof Error && e.message === code, `expected ${code}, got ${e instanceof Error ? e.message : String(e)}`); } }
async function balance(id: string): Promise<bigint> {
  const r = await pool.query<{ balance: string }>(`SELECT COALESCE(SUM(CASE WHEN entry_type='CREDIT' THEN amount_minor ELSE -amount_minor END),0)::text balance FROM ledger_entries WHERE ledger_account_id=$1`, [id]);
  return BigInt(r.rows[0].balance);
}
async function provisionVerified(email: string, name: string, kind: 'CUSTOMER'|'MERCHANT') {
  const u = await provisionUser({ email, displayName: name, kind });
  await runKycCheck(kycProvider, u.userId);
  return u;
}

async function main() {
  const alice = await provisionVerified(`alice-${suffix}@example.test`, 'Alice', 'CUSTOMER');
  const supermarket = await provisionVerified(`market-${suffix}@example.test`, 'Supermarket ABC LTD', 'MERCHANT');
  const supplier = await provisionVerified(`supplier-${suffix}@example.test`, 'Supplier XYZ', 'MERCHANT');
  const employee = await provisionVerified(`employee-${suffix}@example.test`, 'Employee 123', 'CUSTOMER');

  await check('funding / issuance', async () => {
    const r = await fundAndIssue({ userId: alice.userId, walletId: alice.walletId, ledgerAccountId: alice.ledgerAccountId, amountMinor: 10000000n, provider });
    expect(r.status === 'SETTLED', 'issuance not settled');
    expect(await balance(alice.ledgerAccountId) === 10000000n, 'Alice issuance balance mismatch');
  });

  await check('account verification', async () => {
    const r = await provider.verifyAccount('001', '1234567890');
    expect(r.verified, 'account not verified');
    expect(r.accountName === 'SUPERMARKET ABC LTD', 'verified account name mismatch');
  });

  await check('A→B→C→D network-transferable chain', async () => {
    const ab = await createTransfer({ idempotencyKey: `ab-${suffix}`, senderLedgerAccountId: alice.ledgerAccountId, recipientLedgerAccountId: supermarket.ledgerAccountId, amountMinor: 10000000n, actorId: alice.userId });
    const bc = await createTransfer({ idempotencyKey: `bc-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 4000000n, actorId: supermarket.userId });
    const cd = await createTransfer({ idempotencyKey: `cd-${suffix}`, senderLedgerAccountId: supplier.ledgerAccountId, recipientLedgerAccountId: employee.ledgerAccountId, amountMinor: 1000000n, actorId: supplier.userId });
    expect(ab.status === 'SETTLED' && bc.status === 'SETTLED' && cd.status === 'SETTLED', 'chain did not settle');
    const meta = await pool.query<{metadata: any}>(`SELECT metadata FROM transactions WHERE id=$1`, [ab.id]);
    expect(meta.rows[0].metadata.transferability === TRANSFERABILITY, 'transferability metadata missing');
    expect(await balance(alice.ledgerAccountId) === 0n, 'Alice balance wrong');
    expect(await balance(supermarket.ledgerAccountId) === 6000000n, 'Supermarket balance wrong');
    expect(await balance(supplier.ledgerAccountId) === 3000000n, 'Supplier balance wrong');
    expect(await balance(employee.ledgerAccountId) === 1000000n, 'Employee balance wrong');
  });

  await check('idempotency replay', async () => {
    const first = await createTransfer({ idempotencyKey: `bc-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 4000000n, actorId: supermarket.userId });
    const count = await pool.query<{c:string}>(`SELECT count(*)::text c FROM transactions WHERE idempotency_key=$1`, [`bc-${suffix}`]);
    expect(first.status === 'SETTLED' && count.rows[0].c === '1', 'idempotency failed');
  });

  await check('insufficient funds', async () => {
    await expectError(() => createTransfer({ idempotencyKey: `insuff-${suffix}`, senderLedgerAccountId: alice.ledgerAccountId, recipientLedgerAccountId: supermarket.ledgerAccountId, amountMinor: 1n, actorId: alice.userId }), 'INSUFFICIENT_FUNDS');
  });

  await check('KYC enforcement', async () => {
    const u = await provisionUser({ email: `unverified-${suffix}@example.test`, displayName: 'Unverified', kind: 'CUSTOMER' });
    await expectError(() => fundAndIssue({ userId: u.userId, walletId: u.walletId, ledgerAccountId: u.ledgerAccountId, amountMinor: 1000n, provider }), 'KYC_REQUIRED');
    await expectError(() => redeem({ userId: u.userId, walletId: u.walletId, ledgerAccountId: u.ledgerAccountId, amountMinor: 1000n, bankCode: '001', accountNumber: '1234567890', provider }), 'KYC_REQUIRED');
  });

  await check('risk BLOCK and REVIEW enforcement', async () => {
    await pool.query(`UPDATE risk_profiles SET decision='BLOCK', reason='CERT_BLOCK' WHERE user_id=$1`, [supermarket.userId]);
    await expectError(() => createTransfer({ idempotencyKey: `risk-block-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 1000n, actorId: supermarket.userId }), 'CERT_BLOCK');
    await pool.query(`UPDATE risk_profiles SET decision='REVIEW', reason='CERT_REVIEW' WHERE user_id=$1`, [supermarket.userId]);
    await expectError(() => createTransfer({ idempotencyKey: `risk-review-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 1000n, actorId: supermarket.userId }), 'REQUIRES_REVIEW');
    await pool.query(`UPDATE risk_profiles SET decision='ALLOW', reason=NULL WHERE user_id=$1`, [supermarket.userId]);
  });

  await check('transaction limits', async () => {
    await pool.query(`UPDATE account_limits SET single_tx_limit_minor=1000 WHERE owner_id=$1`, [supermarket.userId]);
    await expectError(() => createTransfer({ idempotencyKey: `limit-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 1001n, actorId: supermarket.userId }), 'SINGLE_TRANSACTION_LIMIT');
  });

  await check('webhook signature and idempotency', async () => {
    const body = JSON.stringify({ event: 'funding.confirmed', amountMinor: '1000' });
    const sig = createHmac('sha256', 'secret').update(body).digest('hex');
    expect(verifyWebhookSignature(body, sig, 'secret'), 'valid signature rejected');
    expect(!verifyWebhookSignature(body, 'bad', 'secret'), 'invalid signature accepted');
    const first = await processWebhook({ providerName:'SANDBOX', eventId:`event-${suffix}`, eventType:'FUNDING_CONFIRMED', signatureValid:true, payload:JSON.parse(body) });
    const duplicate = await processWebhook({ providerName:'SANDBOX', eventId:`event-${suffix}`, eventType:'FUNDING_CONFIRMED', signatureValid:true, payload:JSON.parse(body) });
    expect(first.processed === true && duplicate.duplicate === true, 'webhook idempotency failed');
  });

  let transferForRefund = '';
  await check('refund as compensating transaction', async () => {
    const tx = await createTransfer({ idempotencyKey:`refund-source-${suffix}`, senderLedgerAccountId: supermarket.ledgerAccountId, recipientLedgerAccountId: supplier.ledgerAccountId, amountMinor: 100000n, actorId: supermarket.userId });
    transferForRefund = tx.id;
    const before = await balance(supplier.ledgerAccountId);
    const refund = await refundTransfer({ originalTransactionId: transferForRefund, actorId: supermarket.userId, amountMinor: 50000n, idempotencyKey:`refund-${suffix}` });
    expect(refund.status === 'SETTLED', 'refund not settled');
    expect(await balance(supplier.ledgerAccountId) === before - 50000n, 'refund balance mismatch');
    const original = await pool.query(`SELECT status FROM transactions WHERE id=$1`, [transferForRefund]);
    expect(original.rows[0].status === 'SETTLED', 'original transaction mutated');
  });

  let disputeId = '';
  await check('dispute lifecycle', async () => {
    const d = await openDispute({ userId: supplier.userId, transactionId: transferForRefund, reason:'CERTIFICATION_TEST', evidence:{test:true} });
    disputeId = d.id;
    expect(d.status === 'OPEN', 'dispute not open');
    const r = await resolveDispute({ disputeId, actorId: supplier.userId, resolution:'CERTIFIED', status:'RESOLVED' });
    expect(r.status === 'RESOLVED', 'dispute not resolved');
  });

  await check('reconciliation match and exception', async () => {
    const current = await pool.query<{amount:string}>(`SELECT COALESCE(SUM(CASE WHEN la.code='SNGN_BACKING_ASSET' AND le.entry_type='DEBIT' THEN le.amount_minor WHEN la.code='SNGN_BACKING_ASSET' AND le.entry_type='CREDIT' THEN -le.amount_minor WHEN la.code='SNGN_REDEMPTION_ASSET' AND le.entry_type='CREDIT' THEN -le.amount_minor WHEN la.code='SNGN_REDEMPTION_ASSET' AND le.entry_type='DEBIT' THEN le.amount_minor ELSE 0 END),0)::text amount FROM ledger_entries le JOIN ledger_accounts la ON la.id=le.ledger_account_id WHERE la.code IN ('SNGN_BACKING_ASSET','SNGN_REDEMPTION_ASSET')`);
    const internal = BigInt(current.rows[0].amount);
    const match = await runSandboxReconciliation({ externalAmountMinor: internal, providerName:`V1.5-${suffix}` });
    expect(match.status === 'RECONCILED' && match.differenceMinor === '0', 'reconciliation match failed');
    const mismatch = await runSandboxReconciliation({ externalAmountMinor: internal + 1n, providerName:`V1.5-${suffix}` });
    expect(mismatch.status === 'EXCEPTION' && mismatch.differenceMinor === '-1', 'reconciliation exception failed');
    const ex = await pool.query<{id:string}>(`SELECT id FROM reconciliation_exceptions WHERE run_id=$1`, [mismatch.runId]);
    expect(ex.rowCount === 1, 'exception record missing');
    const resolved = await resolveReconciliationException(ex.rows[0].id, 'RESOLVED', 'CERTIFICATION_TEST_RESOLVED', alice.userId);
    expect(resolved.status === 'RESOLVED', 'exception resolution failed');
  });

  await check('database ledger invariant', async () => {
    const r = await pool.query<{id:string; debits:string; credits:string; amount:string}>(`SELECT t.id, t.amount_minor::text amount, COALESCE(SUM(le.amount_minor) FILTER (WHERE le.entry_type='DEBIT'),0)::text debits, COALESCE(SUM(le.amount_minor) FILTER (WHERE le.entry_type='CREDIT'),0)::text credits FROM transactions t LEFT JOIN ledger_entries le ON le.transaction_id=t.id WHERE t.status='SETTLED' GROUP BY t.id HAVING COALESCE(SUM(le.amount_minor) FILTER (WHERE le.entry_type='DEBIT'),0) <> COALESCE(SUM(le.amount_minor) FILTER (WHERE le.entry_type='CREDIT'),0) OR COALESCE(SUM(le.amount_minor) FILTER (WHERE le.entry_type='DEBIT'),0) <> t.amount_minor`);
    expect(r.rowCount === 0, `unbalanced settled transactions: ${r.rowCount}`);
  });

  await check('sandbox evidence generation', async () => {
    const e = await generateSandboxEvidence(`V1.5-${suffix}`);
    expect(e.status === 'PASS', 'evidence did not pass');
    expect(e.artifact.transactions.length > 0 && e.artifact.ledgerEntries.length > 0, 'evidence incomplete');
  });

  const failed = results.filter(r => r.status === 'FAIL');
  const summary = { suite: 'sNGN V1.5 certification', executedAt: new Date().toISOString(), passed: results.length - failed.length, failed: failed.length, results };
  console.log(JSON.stringify(summary, null, 2));
  if (failed.length) process.exitCode = 1;
}

main().catch(err => { console.error(err); process.exitCode = 1; }).finally(() => pool.end());
