# sNGN V1.1 — Connected Sandbox Transaction Network

Sandbox-oriented implementation of the sNGN transferable digital-value core.

## Included in V1.1

- PostgreSQL double-entry ledger
- Integer minor-unit money representation
- Atomic A→B transfers
- A→B→C integration-test scenario support
- Idempotency protection
- User/wallet/ledger provisioning
- API-key authenticated customer/merchant API
- Sandbox funding + controlled issuance
- Sandbox redemption state machine
- Sandbox bank-account verification
- Reconciliation engine
- Immutable settled-transaction controls
- Audit events
- Provider adapter interface

## Money model

The sandbox uses a controlled system account called `SNGN_BACKING_ASSET` as the ledger counterparty for test issuance and `SNGN_REDEMPTION_ASSET` for test redemption. These are **test accounting controls only** and do not represent real reserves or authorization to issue live money.

Production funding, issuance, redemption and payout require the appropriate authorized financial/payment infrastructure, credentials, safeguarding model and regulatory/partner structure.

## Run

```bash
cp .env.example .env
docker compose up -d
npm install
npm run db:migrate
npm run dev
```

Required `.env` values:

```text
DATABASE_URL=postgres://sngn:sngn@localhost:5432/sngn
PORT=3000
ADMIN_PROVISIONING_KEY=change-this-in-development
```

## Provision a sandbox customer

```bash
curl -X POST http://localhost:3000/v1/provisioning/users \
  -H 'x-admin-key: change-this-in-development' \
  -H 'content-type: application/json' \
  -d '{"email":"alice@example.test","displayName":"Alice","kind":"CUSTOMER"}'
```

The response contains a sandbox API key. Treat it as a secret.

## Get wallet

```bash
curl http://localhost:3000/v1/wallets/me \
  -H 'authorization: Bearer sngn_...'
```

## Fund and issue test sNGN

```bash
curl -X POST http://localhost:3000/v1/funding \
  -H 'authorization: Bearer sngn_...' \
  -H 'content-type: application/json' \
  -d '{"amount":"100000.00"}'
```

## Verify a sandbox bank account

```bash
curl -X POST http://localhost:3000/v1/beneficiaries/verify \
  -H 'authorization: Bearer sngn_...' \
  -H 'content-type: application/json' \
  -d '{"bankCode":"SANDBOX_BANK","accountNumber":"0123456789"}'
```

## Transfer

Use the sender's own ledger account and the recipient's ledger account. Supply an `Idempotency-Key`.

```bash
curl -X POST http://localhost:3000/v1/transfers \
  -H 'authorization: Bearer sngn_...' \
  -H 'Idempotency-Key: demo-a-to-b-001' \
  -H 'content-type: application/json' \
  -d '{"senderLedgerAccountId":"SENDER_UUID","recipientLedgerAccountId":"RECIPIENT_UUID","amount":"100000.00"}'
```

## Redeem test sNGN

```bash
curl -X POST http://localhost:3000/v1/redemptions \
  -H 'authorization: Bearer sngn_...' \
  -H 'content-type: application/json' \
  -d '{"amount":"40000.00","bankCode":"SANDBOX_BANK","accountNumber":"0123456789"}'
```

## Reconciliation

The sandbox reconciliation endpoint is admin-protected:

```bash
curl -X POST http://localhost:3000/v1/reconciliation/sandbox \
  -H 'x-admin-key: change-this-in-development' \
  -H 'content-type: application/json' \
  -d '{"externalAmount":"100000.00"}'
```

## V1.1 transaction sequence

1. Provision Alice.
2. Provision Supermarket B.
3. Provision Supplier C.
4. Fund/issue Alice with 100,000 test sNGN.
5. Alice sends 100,000 to B.
6. B sends 40,000 to C.
7. Verify balances and ledger entries.
8. Test duplicate idempotency request.
9. Test insufficient funds.
10. Test redemption.
11. Run reconciliation.

## Production boundary

This repository is not a live-money authorization and must not be represented as one. A production deployment requires the applicable regulatory/partner structure, real provider credentials, security controls, safeguarding/backing arrangements, KYC/AML/CFT controls, monitoring, reconciliation and formal testing/approval.
