# sNGN V1.2 — controlled sandbox transaction network

V1.2 extends the V1.1 ledger with risk/limits, disputes, refunds, signed webhook ingestion, observability, reconciliation visibility, and a generic HTTP payment-provider adapter.

## Important boundary
The generic HTTP adapter is an integration contract for an authorized provider's sandbox. It does not itself confer regulatory authorization or create a live-money rail. Configure live credentials only after the appropriate partner/licensing arrangement is in place.

## New migration
`migrations/003_v12.sql`

Run:

```bash
npm install
npm run db:migrate
npm run typecheck
npm run build
npm test
```

## New endpoints

- `POST /v1/disputes`
- `POST /v1/refunds` (requires `Idempotency-Key`)
- `POST /v1/webhooks/:providerName` with `X-Event-ID` and `X-Signature`
- `GET /v1/observability/metrics` (admin)
- `POST /v1/admin/disputes/:disputeId/resolve` (admin)
- `GET /v1/admin/reconciliation/runs` (admin)

## V1.2 controls

- Per-account single-transaction and daily transfer limits.
- Risk profile decision: ALLOW / REVIEW / BLOCK.
- Refunds are compensating ledger transactions; the original transfer remains in history.
- Webhook signatures use HMAC-SHA256 and event IDs are idempotently stored.
- Provider adapter is separated from the core ledger.
- Operational metrics are persisted for audit/debugging.

## Regulatory evidence mapping

The implementation now produces artifacts that can support controlled testing evidence: transaction IDs, ledger entries, audit events, funding/issuance references, redemption references, reconciliation runs, webhook processing records, disputes, refunds, and operational metrics.
